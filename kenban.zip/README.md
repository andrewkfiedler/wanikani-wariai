To build:
Run 'yarn install' then run 'yarn build'.
Then the distribution folder should appear with the compiled code.
At the moment this is purely a CSS extension.

Description:
Adds keyboard shortcut hints to wanikani!  For those of us who are forgetful (；・∀・)

![image](/screenshots/1.png?raw=true)

![image](/screenshots/2.png?raw=true)